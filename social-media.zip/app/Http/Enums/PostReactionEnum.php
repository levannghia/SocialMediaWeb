<?php

namespace App\Http\Enums;

enum PostReactionEnum: string {
    case LIKE = 'like';
}